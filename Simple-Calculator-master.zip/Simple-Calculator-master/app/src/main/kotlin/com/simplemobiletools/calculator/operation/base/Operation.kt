package com.simplemobiletools.calculator.operation.base

import java.math.BigDecimal

interface Operation {
    fun getResult(): BigDecimal
}
