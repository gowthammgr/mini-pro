package com.simplemobiletools.calculator.operation.base

import java.math.BigDecimal

open class UnaryOperation protected constructor(protected var value: BigDecimal)
